create view allmovies(movid, releasedate) as
SELECT m.movid,
       m.releasedate
FROM movies m;

alter table allmovies
    owner to rdeng4;

